

from wb.api.wildebeest_api import WildebeestApi

api = WildebeestApi()
